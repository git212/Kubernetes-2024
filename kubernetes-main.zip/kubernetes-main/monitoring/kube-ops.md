#### Deploying and Accessing the realtime 
```sh
git clone  https://github.com/schoolofdevops/kube-ops-view
kubectl apply -f kube-ops-view/deploy/
#scale=2.0
# Access the service using nodeport
```



